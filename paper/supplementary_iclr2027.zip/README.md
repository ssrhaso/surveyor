Supplementary code and pre-registration documents (anonymized).

code/            evaluation + training code (root), configs, the spec-accept
                 package (specaccept/), the V-JEPA-2 transplant package
                 (vjepa2/specaccept_vjepa2/), and all cluster batch scripts
                 (batch/; clusterA = the A100 SLURM system, clusterB = the
                 GH200 system used early in the project).
prereg/          the frozen pre-registration documents: definitions, bars,
                 and banked verdicts for every claim in the paper (the
                 provenance referenced from the appendices).
figscripts/      scripts that generate the paper's figures from banked data.

Cluster usernames, hostnames, project codes, and institution names have been
replaced with neutral tokens; SLURM job IDs are retained as opaque provenance
identifiers. Data and checkpoints are not included for size reasons.